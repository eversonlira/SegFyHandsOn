﻿using MySql.Data.MySqlClient;
using System;
using System.Configuration;
using System.Data;
using System.Web.UI.WebControls;
using SegFyHandsOn.Business;

namespace SegFyHandsOn
{
    public partial class InsuranceInsert : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadSegFyInsuranceType();

            }
        }

        /// <summary>
        ///  Carrega os tipos de seguro no dropdown
        /// </summary>
        private void LoadSegFyInsuranceType()
        {
            DataTable dt = new DataTable();
            string strSQL = string.Empty;

            strSQL = "SELECT SegFyInsuranceType, SegFyInsuranceTypeDescription FROM SegFyInsuranceType ";

            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["MySqlConnectionString"].ConnectionString;

                using (MySqlConnection MySqlConn = new MySqlConnection(connStr))
                {
                    MySqlConn.Open();
                    MySqlDataAdapter adpPeople = new MySqlDataAdapter(strSQL, MySqlConn);
                    adpPeople.Fill(dt);
                    adpPeople.Dispose();

                    ddlInsuranceType.DataTextField = "SegFyInsuranceTypeDescription";
                    ddlInsuranceType.DataValueField = "SegFyInsuranceType";
                    ddlInsuranceType.DataSource = dt;
                    ddlInsuranceType.DataBind();
                    ddlInsuranceType.Items.Insert(0, new ListItem("Selecione um tipo", "0"));

                }
            }
            catch (Exception ex)
            {
                lblValidate.Text = "<p class=\"infopostAlert\"><img align=\"left\" alt=\"Alerta\" src=\"img/warning-icon.png\" width=\"24\" /> " +
                                   " &nbsp;&nbsp;Erro ao acessar o banco de dados: LoadSegFyInsuranceType()  " + ex.Message.ToString() + " </p>";
            }
            finally
            {

            }
        }

        /// <summary>
        /// Valida os tipos de seguro no dropdown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void DdlInsuranceType_SelectedIndexChanged(object sender, EventArgs e)
        {
            //0 None 
            //1 Automóvel
            //2 Residencial
            //3 Vida

            panInsuranceForm.Visible = true;
            lblValidate.Text = string.Empty;

            if (ddlInsuranceType.SelectedValue == "0")
            {
                panInsuranceForm.Visible = false;
                lblValidate.Text = "<p class=\"infopostAlert\"><img align=\"left\" alt=\"Alerta\" src=\"img/warning-icon.png\" width=\"24\" /> " +
                                   " &nbsp;&nbsp;Selecione um tipo de seguro para inserir!</p>";

            }
            else if (ddlInsuranceType.SelectedValue == "1")
            {
                divPlate.Visible = true;
                divAddress.Visible = false;
                divInsuredCPF.Visible = false;
            }
            else if (ddlInsuranceType.SelectedValue == "2")
            {
                divPlate.Visible = false;
                divAddress.Visible = true;
                divInsuredCPF.Visible = false;
            }
            else if (ddlInsuranceType.SelectedValue == "3")
            {
                divPlate.Visible = false;
                divAddress.Visible = false;
                divInsuredCPF.Visible = true;
            }
        }

        /// <summary>
        /// Insere um Seguro
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            lblValidate.Text = string.Empty;
            string sInsuranceType = ddlInsuranceType.SelectedValue;
            string sInsuranceClientCPFCNPJ = tbxInsuranceClientCPFCNPJ.Text.Trim().Replace("'", "").Replace(",", " ");

            string sInsuranceObject = tbxInsuranceObject.Text.Trim().Replace("'", "").Replace(",", " ");
            string sInsurancePlate = tbxInsurancePlate.Text.Trim().Replace("'", "").Replace(",", " ");
            string sInsuranceAddress = tbxAddress.Text.Trim().Replace("'", "").Replace(",", " ");
            string sInsuredCPF = tbxInsuredCPF.Text.Trim().Replace("'", "").Replace(",", " ");

            string sValidateInsert = Utile.ValidateInsuranceInsert(sInsuranceType, sInsuranceObject, sInsuranceClientCPFCNPJ, sInsurancePlate, sInsuranceAddress, sInsuredCPF);

            if (sValidateInsert != "OK")
            {
                lblValidate.Text = "<p class=\"infopostAlert\"><img align=\"left\" alt=\"Alerta\" src=\"img/warning-icon.png\" width=\"24\" /> " +
                                   " &nbsp;&nbsp;" + sValidateInsert + "</p>";

                return;
            }

            //INSERT======================================================================== 
            string sSQL = "INSERT INTO `SegFyInsurance` (" +
                          "`SegFyInsuranceClientCPFCNPJ` ," +
                          "`SegFyInsuranceObject` ," +
                          "`SegFyInsuranceType` , " +
                          "`SegFyInsurancePlate` , " +
                          "`SegFyInsuranceAddress` , " +
                          "`SegFyInsuranceCPF`) " +
                          "VALUES ( " +
                          " '" + sInsuranceClientCPFCNPJ + "', '" + sInsuranceObject + "', " + sInsuranceType + ",  '" + sInsurancePlate + "',  " +
                          " '" + sInsuranceAddress + "', " +
                          " '" + sInsuredCPF + "'  ); ";
            try
            {
                MySqlConnection objConexao = new MySqlConnection(ConfigurationManager.ConnectionStrings["MySqlConnectionString"].ConnectionString);
                MySqlDataAdapter objAdapter = new MySqlDataAdapter
                {
                    SelectCommand = new MySqlCommand(sSQL, objConexao)
                };
                objConexao.Open();
                objAdapter.SelectCommand.ExecuteNonQuery();
                objAdapter.Dispose();
                objConexao.Close();
                objConexao.Dispose();

                lblValidate.Text = "<div class=\"infopostSuccess\">Dados inseridos com sucesso!</div>";

                ClearFields();
                panInsuranceForm.Visible = false; 
            }
            catch (Exception ex)
            {
                lblValidate.Text = "<div class=\"infopostAlert\"><img src=\"images/warning-icon.png\" width=\"22\" align=\"left\"/>" +
                                  " Erro ao inserir Seguro: " + ex.Message.ToString() + "</div>";
            } 
        }

        /// <summary>
        /// Limpa os campos do formulário
        /// </summary>
        private void ClearFields()
        {
            ddlInsuranceType.SelectedValue = "0";
            tbxInsuranceClientCPFCNPJ.Text = string.Empty;
            tbxInsuranceObject.Text = string.Empty;
            tbxInsurancePlate.Text = string.Empty;
            tbxAddress.Text = string.Empty;
            tbxInsuredCPF.Text = string.Empty;
        }
    }
}