﻿using MySql.Data.MySqlClient;
using SegFyHandsOn.Business;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SegFyHandsOn
{
    public partial class InsuranceEdit : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadSegFyInsuranceType(); 
            }
        }
         
        /// <summary>
        ///  Carrega os tipos de seguro no dropdown
        /// </summary>
        private void LoadSegFyInsuranceType()
        {
            DataTable dt = new DataTable();
            string strSQL = string.Empty;

            strSQL = "SELECT SegFyInsuranceType, SegFyInsuranceTypeDescription FROM SegFyInsuranceType ";

            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["MySqlConnectionString"].ConnectionString;

                using (MySqlConnection MySqlConn = new MySqlConnection(connStr))
                {
                    MySqlConn.Open();
                    MySqlDataAdapter adpPeople = new MySqlDataAdapter(strSQL, MySqlConn);
                    adpPeople.Fill(dt);
                    adpPeople.Dispose();

                    ddlInsuranceType.DataTextField = "SegFyInsuranceTypeDescription";
                    ddlInsuranceType.DataValueField = "SegFyInsuranceType";
                    ddlInsuranceType.DataSource = dt;
                    ddlInsuranceType.DataBind();
                    ddlInsuranceType.Items.Insert(0, new ListItem("Selecione um tipo", "0"));

                }
            }
            catch (Exception ex)
            {
                lblValidate.Text = "<p class=\"infopostAlert\"><img align=\"left\" alt=\"Alerta\" src=\"img/warning-icon.png\" width=\"24\" /> " +
                                   " &nbsp;&nbsp;Erro ao acessar o banco de dados: LoadSegFyInsuranceType()  " + ex.Message.ToString() + " </p>";
            }
            finally
            {

            }
        }

        /// <summary>
        /// Valida os tipos de seguro no dropdown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void DdlInsuranceType_SelectedIndexChanged(object sender, EventArgs e)
        {
            //0 None 
            //1 Automóvel
            //2 Residencial
            //3 Vida

            panInsuranceForm.Visible = true;
            lblValidate.Text = string.Empty;

            if (ddlInsuranceType.SelectedValue == "0")
            {
                panInsuranceForm.Visible = false;
                lblValidate.Text = "<p class=\"infopostAlert\"><img align=\"left\" alt=\"Alerta\" src=\"img/warning-icon.png\" width=\"24\" /> " +
                                   " &nbsp;&nbsp;Selecione um tipo de seguro para Editar!</p>";

            }
            else if (ddlInsuranceType.SelectedValue == "1")
            {
                divPlate.Visible = true;
                divAddress.Visible = false;
                divInsuredCPF.Visible = false;
            }
            else if (ddlInsuranceType.SelectedValue == "2")
            {
                divPlate.Visible = false;
                divAddress.Visible = true;
                divInsuredCPF.Visible = false;
            }
            else if (ddlInsuranceType.SelectedValue == "3")
            {
                divPlate.Visible = false;
                divAddress.Visible = false;
                divInsuredCPF.Visible = true;
            }
        }

        /// <summary>
        /// Seleciona um seguro pelo seu id
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnFindInsuranceById_Click(object sender, EventArgs e)
        {
            lblValidate.Text = string.Empty;
            string sSegFyInsuranceId = tbxFindInsuranceById.Text.Trim().Replace("'", "");

            if (string.IsNullOrEmpty(sSegFyInsuranceId))
            {
                lblValidate.Text = "<p class=\"infopostAlert\"><img align=\"left\" alt=\"Alerta\" src=\"img/warning-icon.png\" width=\"24\" /> " +
                                  " &nbsp;&nbsp;Informe um Id para buscar um seguro</p>";
                return;
            }
            else
            {
                if (!Utile.IsNumber(sSegFyInsuranceId))
                {
                    lblValidate.Text = "<p class=\"infopostAlert\"><img align=\"left\" alt=\"Alerta\" src=\"img/warning-icon.png\" width=\"24\" /> " +
                                  " &nbsp;&nbsp;Informe um Id numérico para buscar um seguro</p>";
                    return;
                }
            }

            string strSQL = "SELECT " +
                            "`SegFyInsuranceClientCPFCNPJ` ," +
                            "`SegFyInsuranceObject` ," +
                            "`SegFyInsuranceType` , " +
                            "`SegFyInsurancePlate` , " +
                            "`SegFyInsuranceAddress` , " +
                            "`SegFyInsuranceCPF` " +
                            " FROM SegFyInsurance WHERE SegFyInsuranceId = " + sSegFyInsuranceId + " ";

            string connStr = ConfigurationManager.ConnectionStrings["MySqlConnectionString"].ConnectionString;
            DataSet ds = new DataSet();
            using (MySqlConnection MySqlConn = new MySqlConnection(connStr))
            {
                MySqlConn.Open();
                MySqlDataAdapter adpPeople = new MySqlDataAdapter(strSQL, MySqlConn);
                adpPeople.Fill(ds);
                adpPeople.Dispose();

                if (ds.Tables[0].Rows.Count > 0)
                {
                    tbxInsuranceClientCPFCNPJ.Text = ds.Tables[0].Rows[0]["SegFyInsuranceClientCPFCNPJ"].ToString();
                    tbxInsuranceObject.Text = ds.Tables[0].Rows[0]["SegFyInsuranceObject"].ToString();
                    ddlInsuranceType.SelectedValue = ds.Tables[0].Rows[0]["SegFyInsuranceType"].ToString();
                    tbxInsurancePlate.Text = ds.Tables[0].Rows[0]["SegFyInsurancePlate"].ToString();
                    tbxAddress.Text = ds.Tables[0].Rows[0]["SegFyInsuranceAddress"].ToString();
                    tbxInsuredCPF.Text = ds.Tables[0].Rows[0]["SegFyInsuranceCPF"].ToString();

                    panInsuranceForm.Visible = true;

                    if (ddlInsuranceType.SelectedValue == "1")
                    {
                        divPlate.Visible = true;
                        divAddress.Visible = false;
                        divInsuredCPF.Visible = false;
                    }
                    else if (ddlInsuranceType.SelectedValue == "2")
                    {
                        divPlate.Visible = false;
                        divAddress.Visible = true;
                        divInsuredCPF.Visible = false;
                    }
                    else if (ddlInsuranceType.SelectedValue == "3")
                    {
                        divPlate.Visible = false;
                        divAddress.Visible = false;
                        divInsuredCPF.Visible = true;
                    }
                }
                else
                {
                    lblValidate.Text = "<p class=\"infopostAlert\"><img align=\"left\" alt=\"Alerta\" src=\"img/warning-icon.png\" width=\"24\" /> " +
                                       " &nbsp;&nbsp;Nenhum seguro encontrado com o ID informado</p>";

                    panInsuranceForm.Visible = false;
                    ClearFields();
                }
            } 
        }

        /// <summary>
        /// Limpa os campos do formulário
        /// </summary>
        private void ClearFields()
        {
            ddlInsuranceType.SelectedValue = "0";
            tbxInsuranceClientCPFCNPJ.Text = string.Empty;
            tbxInsuranceObject.Text = string.Empty;
            tbxInsurancePlate.Text = string.Empty;
            tbxAddress.Text = string.Empty;
            tbxInsuredCPF.Text = string.Empty;
            tbxFindInsuranceById.Text = string.Empty;
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {

            lblValidate.Text = string.Empty;

            string sSegFyInsuranceId = tbxFindInsuranceById.Text;

            if (string.IsNullOrEmpty(sSegFyInsuranceId))
            {
                lblValidate.Text = "<p class=\"infopostAlert\"><img align=\"left\" alt=\"Alerta\" src=\"img/warning-icon.png\" width=\"24\" /> " +
                                  " &nbsp;&nbsp;Informe um Id para buscar um seguro</p>";
                return;
            }
            else
            {
                if (!Utile.IsNumber(sSegFyInsuranceId))
                {
                    lblValidate.Text = "<p class=\"infopostAlert\"><img align=\"left\" alt=\"Alerta\" src=\"img/warning-icon.png\" width=\"24\" /> " +
                                  " &nbsp;&nbsp;Informe um Id numérico para buscar um seguro</p>";
                    return;
                }
            }

            string sInsuranceType = ddlInsuranceType.SelectedValue;
            string sInsuranceClientCPFCNPJ = tbxInsuranceClientCPFCNPJ.Text.Trim().Replace("'", "").Replace(",", " ");

            string sInsuranceObject = tbxInsuranceObject.Text.Trim().Replace("'", "").Replace(",", " ");
            string sInsurancePlate = tbxInsurancePlate.Text.Trim().Replace("'", "").Replace(",", " ");
            string sInsuranceAddress = tbxAddress.Text.Trim().Replace("'", "").Replace(",", " ");
            string sInsuredCPF = tbxInsuredCPF.Text.Trim().Replace("'", "").Replace(",", " ");

            string sValidateInsert = Utile.ValidateInsuranceInsert(sInsuranceType, sInsuranceObject, sInsuranceClientCPFCNPJ, sInsurancePlate, sInsuranceAddress, sInsuredCPF);

            if (sValidateInsert != "OK")
            {
                lblValidate.Text = "<p class=\"infopostAlert\"><img align=\"left\" alt=\"Alerta\" src=\"img/warning-icon.png\" width=\"24\" /> " +
                                   " &nbsp;&nbsp;" + sValidateInsert + "</p>";

                return;
            }

            string sSQL = "UPDATE `SegFyInsurance`  " +
                         "   SET `SegFyInsuranceClientCPFCNPJ` = '" + sInsuranceClientCPFCNPJ + "', " +
                         "       `SegFyInsuranceObject` = '" + sInsuranceObject + "', " +
                         "       `SegFyInsurancePlate` = '" + sInsurancePlate + "', " +
                         "       `SegFyInsuranceAddress` = '" + sInsuranceAddress + "', " +
                         "       `SegFyInsuranceCPF` = '" + sInsuredCPF + "' " + 
                         " WHERE SegFyInsuranceId = " + sSegFyInsuranceId + "   ";
            try
            {
                MySqlConnection objConexao = new MySqlConnection(ConfigurationManager.ConnectionStrings["MySqlConnectionString"].ConnectionString);
                MySqlDataAdapter objAdapter = new MySqlDataAdapter();
                objAdapter.SelectCommand = new MySqlCommand(sSQL, objConexao);
                objConexao.Open();
                objAdapter.SelectCommand.ExecuteNonQuery();
                objAdapter.Dispose();
                objConexao.Close();
                objConexao.Dispose();

                lblValidate.Text = "<div class=\"infopostSuccess\">Dados alterados com sucesso!</div>";
                panInsuranceForm.Visible = false;
                ClearFields();
            }
            catch (Exception ex)
            {
                lblValidate.Text = "<div class=\"infopostAlert\"><img src=\"images/warning-icon.png\" width=\"22\" align=\"left\"/>" +
                                   " Erro ao alterar Seguro: " + ex.Message.ToString() + "</div>";
            }
        }
    }
}