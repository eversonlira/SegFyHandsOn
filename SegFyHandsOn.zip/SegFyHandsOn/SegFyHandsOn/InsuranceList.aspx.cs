﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SegFyHandsOn
{
    public partial class InsuranceList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadSegFyInsurances();
            }
        }

        private void LoadSegFyInsurances()
        {
            try
            {
                string strSQL = "SELECT " +
                                 "A.`SegFyInsuranceId` ," +
                                 "A.`SegFyInsuranceClientCPFCNPJ` ," +
                                 "A.`SegFyInsuranceObject` ," +
                                 "(Select S.SegFyInsuranceTypeDescription From SegFyInsuranceType S WHERE S.SegFyInsuranceType = A.`SegFyInsuranceType`) AS sSegFyInsuranceType   , " +
                                 "A.`SegFyInsuranceType` , " +
                                 "A.`SegFyInsurancePlate` , " +
                                 "A.`SegFyInsuranceAddress` , " +
                                 "A.`SegFyInsuranceCPF` " +
                                 " FROM SegFyInsurance A ORDER BY A.SegFyInsuranceType ";

                string connStr = ConfigurationManager.ConnectionStrings["MySqlConnectionString"].ConnectionString;
                DataSet ds = new DataSet();
                using (MySqlConnection MySqlConn = new MySqlConnection(connStr))
                {
                    MySqlConn.Open();
                    MySqlDataAdapter adpPeople = new MySqlDataAdapter(strSQL, MySqlConn);
                    adpPeople.Fill(ds, "ds");
                    adpPeople.Dispose();

                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        gvwInsurance.DataSource = ds.Tables["ds"].DefaultView;
                        gvwInsurance.DataBind();
                    }
                    else
                    {
                        lblValidate.Text = "<p class=\"infopostAlert\"><img align=\"left\" alt=\"Alerta\" src=\"img/warning-icon.png\" width=\"24\" /> " +
                                           " &nbsp;&nbsp;Nenhum seguro encontrado</p>";
                    }
                }
            }
            catch (Exception ex)
            {
                lblValidate.Text = "<p class=\"infopostAlert\"><img align=\"left\" alt=\"Alerta\" src=\"img/warning-icon.png\" width=\"24\" /> " +
                                   " &nbsp;&nbsp;Erro ao selecionar Seguros: " + ex.Message.ToString() + " </p>";
            }
        }
    }
}