﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SegFyHandsOn
{
    public partial class Default : System.Web.UI.Page
    { 
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                string sLogout = Request.QueryString["Logout"];
                if (sLogout == "yes")
                {
                    Session.Remove("sAlias");
                    Session.Abandon();
                }
            }
            catch (Exception)
            {
 
            }
        }

        protected void btnEnter_Click(object sender, EventArgs e)
        {
            string sAlias = tbxAlias.Text.Trim();

            if (string.IsNullOrEmpty(sAlias))
            {
                lblValidate.Text = "<p class=\"infopostAlert\"><img align=\"left\" alt=\"Alerta\" src=\"img/warning-icon.png\" width=\"24\" /> " +
                                   " &nbsp;&nbsp;Informe um apelido qualquer para entrar</p>";
                return;
            }
             
            Session.Add("sAlias", sAlias);
            Response.Redirect("InsuranceManagement.aspx");
        }
    }
}