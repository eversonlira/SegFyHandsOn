﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SegFyHandsOn
{
    public partial class InsuranceManagement : System.Web.UI.Page
    {
        public string sAlias;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                sAlias = Session["sAlias"].ToString();
                if (string.IsNullOrEmpty(sAlias))
                { 
                    Response.Redirect("Default.aspx");
                } 
            }
            catch (Exception)
            {
                Response.Redirect("Default.aspx");
            }
        }
    }
}