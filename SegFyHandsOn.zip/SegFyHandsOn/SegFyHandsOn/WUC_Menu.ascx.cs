﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SegFyHandsOn
{
    public partial class WUC_Menu : System.Web.UI.UserControl
    {
        public string sAlias;

        protected void Page_Load(object sender, EventArgs e)
        {

            try
            {
                sAlias = Session["sAlias"].ToString();

            }
            catch (Exception)
            {

            }
        }
    }
}