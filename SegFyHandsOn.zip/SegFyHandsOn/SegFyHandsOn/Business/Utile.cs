﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;

namespace SegFyHandsOn.Business
{
    public class Utile
    {
         
        public static string ValidateInsuranceInsert(string sInsuranceType, string sInsuranceObject, string sInsuranceClientCPFCNPJ, string sInsurancePlate, string sInsuranceAddress, string sInsuredCPF)
        {
            if (string.IsNullOrEmpty(sInsuranceClientCPFCNPJ))
            {
                return "É obrigatório informar o CPF ou CNPJ do Cliente";
            }
            else
            {
                if (!VerifyCPFCNPJ.isCPFCNPJ(sInsuranceClientCPFCNPJ,false))
                {
                    return "É obrigatório informar um CPF ou CNPJ do Cliente válido"; 
                }
            }

            if (string.IsNullOrEmpty(sInsuranceObject))
            {
                return "É obrigatório informar o Objeto/Pessoa segurado(a)";
            }

            //0 None 
            //1 Automóvel
            //2 Residencial
            //3 Vida

            if (sInsuranceType == "0")
            {
                return " Selecione um tipo de seguro para inserir!"; 
            }
            else if (sInsuranceType == "1")
            {
                if (string.IsNullOrEmpty(sInsurancePlate))
                { 
                    return "É obrigatório informar a placa do veículo";
                }
            }
            else if (sInsuranceType == "2")
            {
                if (string.IsNullOrEmpty(sInsuranceAddress))
                {
                    return "É obrigatório informar o endereço do risco";
                }
            }
            else if (sInsuranceType == "3")
            {
                if (string.IsNullOrEmpty(sInsuredCPF))
                {
                    return "É obrigatório informar o CPF do segurado";
                }
                else
                {
                    if (!VerifyCPFCNPJ.isCPFCNPJ(sInsuredCPF, false))
                    {
                        return "É obrigatório informar um CPF do segurado válido";
                    }
                }
            }
             
            return "OK"; 
        }

        public static class VerifyCPFCNPJ
        {
            // o metodo isCPFCNPJ recebe dois parâmetros:
            // uma string contendo o cpf ou cnpj a ser validado
            // e um valor do tipo boolean, indicando se o método irá
            // considerar como válido um cpf ou cnpj em branco.
            // o retorno do método também é do tipo boolean:
            // (true = cpf ou cnpj válido; false = cpf ou cnpj inválido)
            public static bool isCPFCNPJ(string cpfcnpj, bool vazio)
            {
                if (string.IsNullOrEmpty(cpfcnpj))
                    return vazio;
                else
                {
                    int[] d = new int[14];
                    int[] v = new int[2];
                    int j, i, soma;
                    string Sequencia, SoNumero;

                    SoNumero = Regex.Replace(cpfcnpj, "[^0-9]", string.Empty);

                    //verificando se todos os numeros são iguais
                    if (new string(SoNumero[0], SoNumero.Length) == SoNumero) return false;

                    // se a quantidade de dígitos numérios for igual a 11
                    // iremos verificar como CPF
                    if (SoNumero.Length == 11)
                    {
                        for (i = 0; i <= 10; i++) d[i] = Convert.ToInt32(SoNumero.Substring(i, 1));
                        for (i = 0; i <= 1; i++)
                        {
                            soma = 0;
                            for (j = 0; j <= 8 + i; j++) soma += d[j] * (10 + i - j);

                            v[i] = (soma * 10) % 11;
                            if (v[i] == 10) v[i] = 0;
                        }
                        return (v[0] == d[9] & v[1] == d[10]);
                    }
                    // se a quantidade de dígitos numérios for igual a 14
                    // iremos verificar como CNPJ
                    else if (SoNumero.Length == 14)
                    {
                        Sequencia = "6543298765432";
                        for (i = 0; i <= 13; i++) d[i] = Convert.ToInt32(SoNumero.Substring(i, 1));
                        for (i = 0; i <= 1; i++)
                        {
                            soma = 0;
                            for (j = 0; j <= 11 + i; j++)
                                soma += d[j] * Convert.ToInt32(Sequencia.Substring(j + 1 - i, 1));

                            v[i] = (soma * 10) % 11;
                            if (v[i] == 10) v[i] = 0;
                        }
                        return (v[0] == d[12] & v[1] == d[13]);
                    }
                    // CPF ou CNPJ inválido se
                    // a quantidade de dígitos numérios for diferente de 11 e 14
                    else return false;
                }
            }
        }

        public static bool IsNumber(string text)
        {
            Regex regex = new Regex(@"^[-+]?[0-9]*\.?[0-9]+$");
            return regex.IsMatch(text);
        }
    }
}